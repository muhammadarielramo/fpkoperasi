<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Anggota Kolektor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container py-4">
    <h2>Daftar Anggota</h2>
    <p>Dikelola oleh: <strong><?php echo e($name_collector); ?></strong></p>

    <?php if($member->isEmpty()): ?>
        <div class="alert alert-warning">
            Tidak ada member yang ditemukan.
        </div>
    <?php else: ?>
        <table class="table table-bordered table-striped">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Nama anggota</th>
                    <th>Tanggal Penugasan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($item->member_name); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($item->tgl_penugasan)->format('d M Y')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    <a href="<?php echo e(route('tabel-kolektor')); ?>" class="btn btn-secondary mt-3">← Kembali ke Daftar Kolektor</a>
</div>

</body>
</html>
<?php /**PATH C:\laragon\www\fp-koperasi-template\resources\views/admin/kolektor-anggota.blade.php ENDPATH**/ ?>