<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Relasi Kolektor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
    <h3>Tambah Kolektor untuk Anggota</h3>

    <form action="<?php echo e(route('relasi.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="member" class="form-label">Nama Anggota</label>
            <input type="text" class="form-control" value="<?php echo e($member->user->name); ?>" disabled>
            <input type="hidden" name="id_member" value="<?php echo e($member->id); ?>">
        </div>

        <div class="mb-3">
            <label for="kolektor" class="form-label">Pilih Kolektor</label>
            <select name="id_collector" class="form-select" required>
                <option value="" disabled selected>-- Pilih Kolektor --</option>
                <?php $__currentLoopData = $kolektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->id); ?>"><?php echo e($k->user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="tgl_penugasan" class="form-label">Tanggal Penugasan</label>
            <input type="date" name="tgl_penugasan" class="form-control" required>
        </div>


        <button type="submit" class="btn btn-primary">Simpan Relasi</button>
        <a href="<?php echo e(route('tabel-anggota')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\fp-koperasi-template\resources\views/relation/create.blade.php ENDPATH**/ ?>