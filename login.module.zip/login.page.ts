import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular'; // <<< Tambahin ini!

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [IonicModule], // <<< Tambahin ini!
})
export class LoginPage {
  showPassword = false;

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }
}
